/* Device voice preferences only. No recordings, remote requests or learner data. */
(()=>{
  const KEY='com11-design-foundations-voice-v1', mounts=new Set();
  const available=()=>typeof speechSynthesis==='undefined'?[]:speechSynthesis.getVoices();
  const key=v=>JSON.stringify([v.voiceURI,v.lang,v.name]);
  let preference={voice:'',rate:1};
  try{const saved=JSON.parse(localStorage.getItem(KEY));if(saved&&typeof saved==='object'){if(typeof saved.voice==='string')preference.voice=saved.voice;if(Number.isFinite(saved.rate))preference.rate=Math.max(.7,Math.min(1.3,saved.rate));}}catch{}
  function preferred(voices){
    const names=['Daniel','Samantha','Karen','Moira','Tessa'];
    const english=voices.filter(v=>/^en(?:[-_]|$)/i.test(v.lang));
    const enhanced=english.find(v=>/enhanced|premium|natural/i.test(v.name));
    return enhanced||names.map(n=>english.find(v=>v.name===n)).find(Boolean)||english.find(v=>v.default)||english[0]||voices.find(v=>v.default)||voices[0];
  }
  function selection(){const voices=available();return voices.find(v=>key(v)===preference.voice)||preferred(voices);}
  function persist(){try{localStorage.setItem(KEY,JSON.stringify(preference));}catch{}}
  function configure(utterance){const voice=selection();if(voice){utterance.voice=voice;utterance.lang=voice.lang;}else utterance.lang='en-CA';utterance.rate=preference.rate;return voice?.name||'the device default';}
  function refresh(){
    const voices=available();
    for(const m of mounts){
      if(!m.host.isConnected){mounts.delete(m);continue;}
      const {select,note}=m;select.replaceChildren();
      if(!voices.length){const option=document.createElement('option');option.textContent='Device default (waiting for voices)';option.value='';select.append(option);select.disabled=true;note.textContent='This browser has not listed voices yet. Read the transcript, or try Preview voice to activate speech.';continue;}
      select.disabled=false;
      const ordered=[...voices].sort((a,b)=>(/^en[-_]/i.test(b.lang)?1:0)-(/^en[-_]/i.test(a.lang)?1:0)||a.name.localeCompare(b.name));
      for(const voice of ordered){const option=document.createElement('option');option.value=key(voice);option.textContent=`${voice.name} · ${voice.lang}`;select.append(option);}
      const chosen=selection();select.value=chosen?key(chosen):'';
      note.textContent=preference.voice&&!voices.some(v=>key(v)===preference.voice)?'Your saved voice is unavailable here. A fallback is selected; choose another if needed.':'Voice and speed are saved on this device. Preview before reading.';
    }
  }
  function mount(host,{onChange=()=>{},onPreview=()=>{}}={}){
    if(!host)return;
    host.replaceChildren();host.classList.add('voice-settings');
    const voiceLabel=document.createElement('label');voiceLabel.append('Voice ');const select=document.createElement('select');select.setAttribute('aria-label','Narration voice');voiceLabel.append(select);
    const rateLabel=document.createElement('label');rateLabel.append('Speed ');const rate=document.createElement('select');rate.setAttribute('aria-label','Narration speed');
    for(const value of [.7,.85,1,1.15,1.3]){const opt=document.createElement('option');opt.value=String(value);opt.textContent=value+'×';rate.append(opt);}if(![.7,.85,1,1.15,1.3].includes(preference.rate))preference.rate=1;rate.value=String(preference.rate);rateLabel.append(rate);
    const preview=document.createElement('button');preview.type='button';preview.textContent='Preview voice';const note=document.createElement('p');note.className='voice-note';note.setAttribute('role','status');host.append(voiceLabel,rateLabel,preview,note);
    const m={host,select,note};mounts.add(m);
    select.onchange=()=>{preference.voice=select.value;persist();onChange();refresh();};rate.onchange=()=>{preference.rate=Number(rate.value);persist();onChange();};preview.onclick=()=>{refresh();onPreview('Good design has a job. Let’s look at the message, the audience, and the choices that help a reader.');};
    if(typeof speechSynthesis==='undefined'){select.disabled=true;rate.disabled=true;preview.disabled=true;note.textContent='Speech is unavailable in this browser. The full transcript remains available.';}else refresh();
  }
  if(typeof speechSynthesis!=='undefined')speechSynthesis.addEventListener('voiceschanged',refresh);
  window.LS_SPEECH={configure,mount};
})();
